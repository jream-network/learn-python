people = "Jesse"
place = "Barn"

sentence = "I went to the {0} with {1}.".format(place, people)
print sentence
print sentence.lower()
print sentence.upper()

info = "I like going swimming."
print info[5:10]
print info[-5:]
print info[::-1]