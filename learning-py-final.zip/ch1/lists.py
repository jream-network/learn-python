ages = [12, 15, 16, 17, 22]

print ages
ages.append(200)
ages.insert(1, 13)
ages.remove(22) # Removes the VALUE
ages.pop(0)
print ages

names = ["Ted", "Ben", "Jim", "Betty"]
#names.sort()
#names.reverse()
print names

print names[::-1]