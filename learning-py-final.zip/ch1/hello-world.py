print "Hello World \nIt's a nice day!"
