# Boolean: True or False
num = 60

if num > 20:
    if num > 50:
        print "Thats a high number!"
    else:
        print "Thats a safe bet!"
else:
    print 'Number is too low'

ages = [1, 5, 10]

if 5 in ages:
    print "A toddler is here!"

if num == 60:
    print "You are right on!"

# None is like NULL or NIL
data = None

if data is None:
    print "Data is nothing!"