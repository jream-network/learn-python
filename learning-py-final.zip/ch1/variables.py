name = "Jesse"
age = 25
hobbies = ["swimming", "tennis"]
animals = {
    "farm": "pig",
    "house": "dog"
}
cup = (1, 2, 3)
boolean = True
time = False
null = None

print name
print age
print hobbies
print animals

print boolean
print time
print None

print cup