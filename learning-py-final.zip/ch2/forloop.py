items = range(0,11,5)
print items

for i in items:
    print i
else:
    print "We reached the end"