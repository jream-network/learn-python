#import math
from math import ceil, floor

num = 5.51
#print math.ceil(num)
#print math.floor(num)

print c(num)
print floor(num)